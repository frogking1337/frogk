export const BLOCKCHAIN_LOGO_BASE_URL = "https://blockchain-api.xyz/logos/";
