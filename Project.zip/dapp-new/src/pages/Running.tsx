const Running = ()=>{
    return <div className="runing">
    <div>
      <ul className="center flex">
        <li>
          <p className="title">100 </p> 
          <p className="sub">Active Validators </p>
        </li>
        <li>
          <p className="title">135M+</p>
          <p className="sub">Unique addresses</p>
        </li>
        <li>
          <p className="title">13K</p>
          <p className="sub">Delegators on PoS</p>
        </li>
        <li>
          <p className="title">1.8B</p>
          <p className="sub">Total Transactions</p>
        </li>
        <li>
          <p className="title">~4B</p>
          <p className="sub">Total Matic Staked</p>
        </li>
        <li >
          <p className="title">145K+</p> 
          <p className="sub">Contract Creators</p>
        </li>
        <li>
          <p className="title">$140M</p> 
          <p className="sub">Avg Daily Gas Saved</p>
        </li>   
        <li>
          <p className="title">100 </p> 
          <p className="sub">Active Validators </p>
        </li>
        <li>
          <p className="title">135M+</p>
          <p className="sub">Unique addresses</p>
        </li>
        <li>
          <p className="title">13K</p>
          <p className="sub">Delegators on PoS</p>
        </li>
        <li>
          <p className="title">1.8B</p>
          <p className="sub">Total Transactions</p>
        </li>
        <li>
          <p className="title">~4B</p>
          <p className="sub">Total Matic Staked</p>
        </li>
        <li >
          <p className="title">145K+</p> 
          <p className="sub">Contract Creators</p>
        </li>
        <li>
          <p className="title">$140M</p> 
          <p className="sub">Avg Daily Gas Saved</p>
        </li>
        <li>
          <p className="title">100 </p> 
          <p className="sub">Active Validators </p>
        </li>
        <li>
          <p className="title">135M+</p>
          <p className="sub">Unique addresses</p>
        </li>
        <li>
          <p className="title">13K</p>
          <p className="sub">Delegators on PoS</p>
        </li>
        <li>
          <p className="title">1.8B</p>
          <p className="sub">Total Transactions</p>
        </li>
        <li>
          <p className="title">~4B</p>
          <p className="sub">Total Matic Staked</p>
        </li>
        <li >
          <p className="title">145K+</p> 
          <p className="sub">Contract Creators</p>
        </li>
        <li>
          <p className="title">$140M</p> 
          <p className="sub">Avg Daily Gas Saved</p>
        </li>
      </ul>
    </div>
  </div>
}

export default Running