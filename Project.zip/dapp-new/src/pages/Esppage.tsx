import React, { useEffect, useState } from 'react'
import '../styles/style.css'
import PageSelector from './PageSelector'
import Running from './Running'
import ESPmobile from './Mobilepages/Espmobile'
const twitter  = require('../images/twitter.png')
const reddit  = require('../images/reddit.png')
const discord  = require('../images/discord.png')
const youtube  = require('../images/youtube.png')
const tg  = require('../images/tg.png')
const mail  = require('../images/mail.png')
const lightBnb = require('../images/light-bnb-coins.png')
const lightBnbAir = require('../images/light-bnb-coins-air.png')
const logoGrey = require("../images/logo-p-grey.png")


const Esppage: React.FC = () => {
  const [dimensions, setDimensions] = useState({ 
    height: window.innerHeight,
    width: window.innerWidth
  });

  useEffect(() => {
    function handleResize() {
      setDimensions({
        height: window.innerHeight,
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [window.innerWidth])

  return (
    <div>{
      dimensions.width<1000?
     (<ESPmobile/>)
     :
     (
    <div className="main-container">
       <PageSelector/>
    <div className="p2">
      <div>
        <p className="grey">PROPIEDAD Y OPERACIÓN COMUNITARIA</p>
        <p className="white">Interchain agrícola de rendimiento estable y rentable.</p>
        <button className="learn" style={{cursor: "pointer"}}>Aprender <span>&#8594;</span> </button>
      </div>
      <div></div>
      <div className="p2-1">
        <p className="white" style={{fontWeight: "700"}}>8 to 17%</p>
        <p className="swhite">ROI diario</p>
        <p className="white" style={{fontWeight: "700"}}>5 niveles</p>
        <p className="swhite">De las recompensas por recomendación</p>
      </div>
    </div>
  
    <Running/>
    <p className="grey" style={{marginLeft: "35%", marginTop: "10%"}}>ENTRAR EN EL Paradigm</p>
    <p className="white" style={{marginLeft: "35%", width: '35vh', marginTop: '-15px'}}>La mejor manera de
      ganar activos.</p>
    <div className="back"> 
      <div className="p3">
        <div className="grid1"> 
          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Totalmente auditable</p>
            <p className="subtitle">Todos los contratos inteligentes de Paradigm se han sometido a extensas revisiones internas por parte de nuestros ingenieros de solidez altamente sofisticados, además de múltiples auditorías de seguridad externas. Los Contratos Paradigm son totalmente auditables por cualquier persona.</p>
          </div>

          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Descentralizado</p>
            <p className="subtitle">Las transacciones son gestionadas por el conjunto de validadores Paradigm con gobierno descentralizado. Los grupos solo pueden mover activos entre las posiciones prescritas y solo los usuarios pueden retirar sus fondos.</p>
          </div>

          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Puente seguro</p>
            <p className="subtitle">Nuestro puente Ethereum se usa solo para pasar instrucciones de estrategia. No fluyen fondos reales entre Cosmos y Ethereum.</p>
          </div>
          
          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Ejecución rápida</p>
            <p className="subtitle">La gestión automatizada de firmas para transacciones permite que las estrategias muevan rápidamente la liquidez y capturen el rendimiento en cualquier protocolo DeFi.</p>
          </div>

          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Cosmos Stargate SDK</p>
            <p className="subtitle">El protocolo modular y robusto con Tendermint Consensus ofrece una capa de protocolo probada y de clase mundial.</p>
          </div>
          
          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Sin custodia</p>
            <p className="subtitle">Somos un protocolo sin custodia. El dinero se almacena directamente en los contratos inteligentes de Ethereum y se deposita en AAVE. Los usuarios tienen la tranquilidad de que siempre pueden retirar sus fondos</p>
          </div>
        <button className="learn" style={{cursor: "pointer"}}>
        Aprender &#8594; 
        </button>
        </div>
        
        <div className="p3-1">
          <p className="white" style={{width: '60%', marginTop: "-2.3%"}}>Tecnología blockchain que realmente escala.</p>
          <p className="subtitle" style={{marginTop: "-3.5%"}}>Los servicios generan tarifas.</p>
          <p className="white" style={{fontWeight: "700", marginTop: '10%', width: '70%'}}>Las tarifas generan recompensas.</p>
          <p className="subtitle" style={{marginTop: '-3.5%', width: "55%"}}>Paradigm empodera a las comunidades para construir redes sociales autónomas en las que cada usuario puede tener voz, crear valor y beneficiarse de la creación de valor de los demás. Las tarifas de transacción se distribuyen a los titulares de activos en participación.</p>
          <p className="subtitle" style={{fontWeight: "600"}}>What is staking &#8594;</p>
        </div>
      </div>
    </div>
    <div className="grid5">
      <div className="block11">
        <p className="subtitle">Gen 1.0</p>
        <p className="subtitle">Gen 2.0</p>  
      </div>
      <div className="block12">
        <p className="subtitle" style={{marginTop: "1%"}}>Gen 3.0</p>
        
      </div>
    </div>
    <div className="block13" >
      <div>
        <p style={{fontStyle: "normal", fontWeight: '700', fontSize: '64px', lineHeight: '72px', marginTop: "-5%"}}>Lista para comenzar a apostar?</p>
        <p className="subtitle" style={{fontWeight: '600', width: "70%"}}>Cuanta más actividad en el Hub, más tarifas pagan los servicios, lo que a su vez genera recompensas para los titulares de Paradigm apostados.</p>
        <button className="learn" style={{width: "220px", marginTop: '10%', cursor: "pointer"}}>STAKE</button>
      </div>
      <img className="photo" src={lightBnbAir} alt=''/>
    </div>
    
    <div className="flex1" style={{marginTop: "5%"}}>
      <div className="block14" id="a"  style={{gridArea: "A", paddingLeft: "7%"}}>
        <p className="grey" style={{marginTop:" 0%"}}>HOLDERS</p>
        <img className="photo2" src={lightBnb} alt=''/>
        <p className="swhite2" >Bucear profundo en Paradigm.</p>
      </div>     
      <div className="block15" id="b" style={{gridArea: "B"}}>
        <p className="grey" style={{marginTop: "-2%", marginLeft: "-2%"}}>Conectar</p>
        <p className="swhite2" style={{fontWeight: '700', marginLeft: "-2%"}}>Conectar cadenas</p>
        <p style={{fontStyle: "normal", fontWeight: "500", fontSize: "18px", lineHeight: "23px", color: "#9D9D9D", width: "50%", marginLeft: "-2%"}}>Paradigm permitirá a los usuarios intercambiar sin problemas activos digitales provenientes de todo Interchain.</p>  
      </div>     
      <div className="block16"style={{gridArea: "C"}} id="c">
        <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>Integrar</p>
        <p className="swhite2" style={{width: "", marginLeft: "1%"}}>Proporcionar liquidez. Gana recompensas.</p>    
      </div>
      <div className="block17" id="d" style={{gridArea: "D"}}>
        <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>VALIDAR</p>
        <p className="swhite2" style={{fontWeight: "700", width: "70%"}}>+ Ethereum + Bitcoin</p>
     
      </div>
    </div> 
   
    
    <div className="grid4">
      <div> 
        <p className="swhite2" style={{fontSize: "38px", marginBottom: "-15px"}}>Recibir transmisiones</p>
        <p className="grey">Darse de baja en cualquier momento. <a href="#" className="link1">Política de privacidad↗</a></p>
      </div> 
      <form style={{marginLeft:"0%", marginRight: "0px", marginTop: "5%"}}>
        <label></label>
        <input type="email" className="email" placeholder="Your Email" style={{width: "90%", height: "52px", background: "#262524", borderRadius:" 12px", fontStyle: "normal", fontWeight: "400", fontSize: "28px", lineHeight: "36px", color: "#9D9D9D", paddingLeft: "10px", marginTop: "4%", marginLeft: "auto", marginRight:"0px"}} />
      </form>
    </div>
    <hr/>
    <div className="last">
      <div className="links">
        <p className="grey" style={{color: "white", fontSize: "28px"}}>construir</p>
        <p className="grey" style={{color: "white", fontSize: "28px"}}>depósito</p>
        <p className="grey" style={{color: "white", fontSize: "28px"}}>participar</p>
        <a href="#"  className="link1">Deposit↗</a>
        <a href="#"  className="link1">auditoría↗</a>
        <a href="#"  className="link1">telegram↗</a>
        <a href="#"  className="link1">ibc protocol↗</a>
        <a href="#"  className="link1">contrato↗</a>
        <a href="#"  className="link1">Community↗</a>
        <a href="#"  className="link1">staking↗</a>
        <a href="#"  className="link1">Wallets</a>
      </div>
      <img src={mail} style={{margin: "auto"}} alt=''/>
    </div>
    <hr/>
    <div className="end">
      <img src={logoGrey} style={{width: '15%', height: '10%', marginTop: "auto"}} alt=''/>
      <div style={{marginTop: "1%", marginLeft:"auto"}}>
        <img src={twitter} style={{margin: "5px"}} alt=''/>
        <img src={reddit} style={{margin: "5px"}}/>
        <img src={tg} style={{margin: "5px"}} alt=''/>
        <img src={discord} style={{marginLeft: "5px", marginRight: "5px", marginBottom: "2px"}} alt=''/>
        <img src={youtube} style={{margin: "5px"}} alt=''/>
      </div>
    </div>  
      <p style={{fontStyle: "normal", fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: "#9D9D9D"}}>Este sitio web es mantenido por Paradigm. Los contenidos y opiniones de este sitio web son los de los activos. Paradigm proporciona enlaces a intercambios de criptomonedas como un servicio para el público. Paradigm no garantiza que la información proporcionada por estos sitios web sea correcta, completa y actualizada. Paradigm no es responsable de su contenido y rechaza expresamente cualquier responsabilidad por daños de cualquier tipo que resulten del uso, la referencia o la confianza en cualquier información contenida en estos sitios web.</p>
   
  
  </div>)}
  </div>
  )
}
export default Esppage;