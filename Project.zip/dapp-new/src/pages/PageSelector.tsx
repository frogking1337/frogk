import '../styles/style.css'
import Home from './Wallet/Wallet';
const logoP  = require('../images/logo-p.png')


const PageSelector: React.FC = () => {
    return (
    <main className="p1">
      <div style={{textAlign:'left', width: '35%'}}><img className='logoMain' src={logoP} alt='' style={{width: '160px'}}/></div>
      <div className="dropdown">
        { window.location.pathname==='/'?
           <img width="40px" alt='' src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Flag_of_the_United_Kingdom_%283-5%29.svg/250px-Flag_of_the_United_Kingdom_%283-5%29.svg.png"/>
           : window.location.pathname==='/ru'?
           <img width="40px" alt='' src="https://upload.wikimedia.org/wikipedia/en/thumb/f/f3/Flag_of_Russia.svg/250px-Flag_of_Russia.svg.png"/>
            : window.location.pathname==='/esp'?
            <img width="40px" alt='' src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/250px-Flag_of_Spain.svg.png"/>:
            <img width="40px" alt='' src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/192px-Flag_of_the_People%27s_Republic_of_China.svg.png"/>
        }
         <div className="dropdown-content">   
          <a href="./" style={{display: window.location.pathname==='/'?'none':'block', marginTop:'-1%'}}><img style={{verticalAlign: 'baseline', width:"18px"}} alt='' src="https://upload.wikimedia.org/wikipedia/commons/thumb/8/83/Flag_of_the_United_Kingdom_%283-5%29.svg/250px-Flag_of_the_United_Kingdom_%283-5%29.svg.png"/> <span className="lang">English</span> </a>
          <a href="./zh" style={{display: window.location.pathname==='/zh'?'none':'block', marginTop:'-1%'}}><img style={{verticalAlign: 'baseline', width:"18px"}} alt='' src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/fa/Flag_of_the_People%27s_Republic_of_China.svg/192px-Flag_of_the_People%27s_Republic_of_China.svg.png"/> <span className="lang">中国</span> </a>
          <a href="./esp" style={{display: window.location.pathname==='/esp'?'none':'block', marginTop:'-1%'}}><img style={{verticalAlign: 'baseline', width:"18px" }} alt=''  src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9a/Flag_of_Spain.svg/250px-Flag_of_Spain.svg.png"/> <span className="lang">Español</span> </a>
          <a href="./ru" style={{display: window.location.pathname==='/ru'?'none':'block', marginTop:'-1%'}}><img style={{verticalAlign: 'baseline', width:"18px" }} alt=''  src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/Flag_of_Russia.svg/250px-Flag_of_Russia.svg.png"/> <span className="lang">Русский</span> </a>
        </div>
      </div>
      <div style={{width: '40%'}}>
        <button className="launch" style={{cursor: "pointer", float:'right'}} onClick={()=>{window.location.pathname='/app'}}>Launch App</button>
      </div>
     
    </main>
       
    )
}

export default PageSelector;