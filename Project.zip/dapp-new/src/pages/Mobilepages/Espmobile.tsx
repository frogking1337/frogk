import React from 'react'
import '../../styles/stylesMin.css'
import PageSelector from '../PageSelector'
const twitter  = require('../../images/twitter.png')
const reddit  = require('../../images/reddit.png')
const discord  = require('../../images/discord.png')
const youtube  = require('../../images/youtube.png')
const tg  = require('../../images/tg.png')
const lightBnb = require('../../images/light-bnb-coins.png')
const lightBnbAir = require('../../images/light-bnb-coins-air.png')
const logoGrey = require("../../images/logo-p-grey.png")


const ESPmobile: React.FC = () => {
   
  return  ( 
          <div className="container">
              <PageSelector/>
              <div className="main1" style={{width: "75%"}}>
                <p className="grey" style={{marginTop:' 3%', marginBottom: '-5%'}}>
                PROPIEDAD Y OPERACIÓN COMUNITARIA
                </p>
                <p className="white">Interchain agrícola de rendimiento estable y rentable.</p>
              </div>

            <div className="main2">
              <div style={{marginRight: 'auto', width: '80%'}}>
                <p className="white" style={{fontWeight: '700'}}>8 to 17%</p>
                <p style={{fontWeight: '400', fontSize: '25px', lineHeight: '32px', marginTop: "-17%"}}>ROI diario</p>
              </div>
              <div style={{marginLeft: 'auto'}}>
                <p className="white" style={{fontWeight:"700"}}>5 niveles</p>
                <p style={{fontWeight: '400', fontSize: '25px', lineHeight: '32px', marginTop: "-15%"}}>De las recompensas por recomendación</p>
              </div>
            </div>
           <button className="learn">Aprender <span>&#8594;</span></button>
            
            <p className="grey" style={{marginTop: "20%"}}>ENTRAR EN EL Paradigm</p>
            <p className="white" style={{marginTop: "-2%", width: "65%"}}>La mejor manera de
      ganar activos.</p>

            <div className="main3">
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: '30px'}}>Totalmente auditable</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Todos los contratos inteligentes de Paradigm se han sometido a extensas revisiones internas por parte de nuestros ingenieros de solidez altamente sofisticados, además de múltiples auditorías de seguridad externas. Los Contratos Paradigm son totalmente auditables por cualquier persona.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: '30px'}}>Descentralizado</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color:"#D3D3D3"}}>Las transacciones son gestionadas por el conjunto de validadores Paradigm con gobierno descentralizado. Los grupos solo pueden mover activos entre las posiciones prescritas y solo los usuarios pueden retirar sus fondos.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Puente seguro</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Nuestro puente Ethereum se usa solo para pasar instrucciones de estrategia. No fluyen fondos reales entre Cosmos y Ethereum.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)', backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Ejecución rápida</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>La gestión automatizada de firmas para transacciones permite que las estrategias muevan rápidamente la liquidez y capturen el rendimiento en cualquier protocolo DeFi.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)', backgroundRepeat: 'no-repeat', backgroundSize:"cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Cosmos Stargate SDK</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>El protocolo modular y robusto con Tendermint Consensus ofrece una capa de protocolo probada y de clase mundial.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)', backgroundRepeat: 'no-repeat', backgroundSize: "cover" }}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Sin custodia</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Somos un protocolo sin custodia. El dinero se almacena directamente en los contratos inteligentes de Ethereum y se deposita en AAVE. Los usuarios tienen la tranquilidad de que siempre pueden retirar sus fondos</p>
              </div>
              <button className="learn">Aprender <span>&#8594;</span></button>
            </div>
            <div className="back">
              <p className="white" style={{marginTop: '55%', width: "80%"}}>Los servicios generan tarifas.</p>
              <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: '#D3D3D3', marginTop: "-5%"}}>Tecnología blockchain que realmente escala.</p>

              <p className="white" style={{fontWeight: '700', marginTop: '15%', marginBottom: '-1%', width:"80%"}}>Las tarifas generan recompensas.</p>
              <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: '#D3D3D3', width: '60%'}}>Paradigm empodera a las comunidades para construir redes sociales autónomas en las que cada usuario puede tener voz, crear valor y beneficiarse de la creación de valor de los demás. Las tarifas de transacción se distribuyen a los titulares de activos en participación.</p>
              <p style={{fontWeight: '600', fontSize: '19px', lineHeight: '25px'}}>What is staking <span>&#8594;</span></p>
            </div>
            <div className="main4">
              <div className="block block1" style={{width: '90%'}}> 
                <p className="subtitle">Gen 1.0</p>
                <p className="subtitle" style={{marginTop: "90%"}}>Gen 2.0</p>
              </div>
              <div className="block block2">
                <p className="subtitle">Gen 3.0</p>
                
              </div>
            </div>
            <div className="block block3 flex2">
              <div>
                <p className="white" style={{width: '80%', marginTop: 'auto', lineHeight: '24px', fontSize: "24px"}}>Lista para comenzar a apostar?</p>
                <p style={{fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: '#D3D3D3', width: '85%', marginTop: "-5%"}}>Cuanta más actividad en el Hub, más tarifas pagan los servicios, lo que a su vez genera recompensas para los titulares de Paradigm apostados.</p>
                <button className="learn" style={{width: '129px', height: "33px"}}>STAKE</button>
              </div>
              <img src={lightBnbAir} style={{width: '165%', marginLeft: "-40%", marginTop:'-20%'}}/>
            </div>  
            <div className="main5"> 
              <div className="block block4" id="a">
                <p className="grey" style={{width: '100%',  fontSize: '18px', marginTop:' 12%'}}>HOLDERS</p>
                <img src={lightBnb} style={{width: "130%"}}/>
                <p className="white" style={{fontWeight: '700', fontSize: '21px', lineHeight: 'normal', width:"120%"}}>Bucear profundo en Paradigm.</p>
              </div>
              <div className="block block5" id="b">
                <p className="grey" style={{marginTop: '5%',  fontSize: "18px"}}>Conectar</p>
                <p style={{fontWeight: '700', fontSize: '21px', lineHeight: 'normal', marginTop: "5%"}}>Conectar cadenas</p>
                <p style={{fontWeight: '500', fontSize: '14px', lineHeight: '18px', color: '#9D9D9D', marginTop: '5%', width:"100%"}}>Paradigm permitirá a los usuarios intercambiar sin problemas activos digitales provenientes de todo Interchain.</p>
              </div>
              <div className="block block6" id="c">
                <p className="grey" style={{marginTop: '5%', fontSize: '18px'}}>Integrar</p>
                <p style={{fontWeight: '600', fontSize: '21px', marginTop: '-5%', width: '80%', lineHeight: "normal"}}>Proporcionar liquidez. Gana recompensas.</p>
              </div>
            </div>

            <div> 
              <p className="swhite2" style={{fontSize: '38px', marginBottom:"-15px"}}>Recibir transmisiones</p>
              <p className="grey">Darse de baja en cualquier momento.</p>
              <a href="#" className="link1 grey" style={{marginLeft:'1%', marginTop: "-1%"}}>Política de privacidad↗</a>
            </div>
            <form style={{marginLeft: '-20%', marginRight: '0px', marginTop: "5%"}}>
              <label></label>
              <input type="email" className="email" placeholder="Your Email" style={{width: '64%', height: '52px', background: '#262524', borderRadius: '12px', fontStyle: 'normal', fontWeight: '400', fontSize: '18px', lineHeight: '36px', color: '#9D9D9D', paddingLeft: '10px', marginTop: '4%', marginLeft: '25%', marginBottom: '5%', border: "none"}} />
            </form>
            <hr/>
            <div className="last">
              <div className="links">
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>construir</p>
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>depósito</p>
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>participar</p>
                <a href="#"  className="link1">Deposit↗</a>
                <a href="#"  className="link1">auditoría↗</a>
                <a href="#"  className="link1">telegram↗</a>
                <a href="#"  className="link1">ibc protocol↗</a>
                <a href="#"  className="link1">contrato↗</a>
                <a href="#"  className="link1">Community↗</a>
                <a href="#"  className="link1">staking↗</a>
                <a href="#"  className="link1">Wallets</a>
              </div>
            </div>
            <hr/>
            <div className="end" style={{flexDirection: 'column'}}>
              <div className="flex">
                <img src={logoGrey} style={{width: '35%', height: '10%', marginTop: "13px"}}/>
                <div style={{marginTop: '2.5%', marginLeft:"auto"}}>
                  <img src={twitter} style={{margin: "5px"}}/>
                  <img src={reddit} style={{margin: "5px"}}/>
                  <img src={tg} style={{margin: "5px"}}/>
                  <img src={youtube} style={{margin: '5px', marginBottom: "3px"}}/>
                  <img src={discord} style={{margin: "5px"}}/>
                </div>
              </div>
              <p style={{fontStyle: 'normal', fontWeight: '500', fontSize: '9px', lineHeight: '15px', color: "#9D9D9D"}}>Este sitio web es mantenido por Paradigm. Los contenidos y opiniones de este sitio web son los de los activos. Paradigm proporciona enlaces a intercambios de criptomonedas como un servicio para el público. Paradigm no garantiza que la información proporcionada por estos sitios web sea correcta, completa y actualizada. Paradigm no es responsable de su contenido y rechaza expresamente cualquier responsabilidad por daños de cualquier tipo que resulten del uso, la referencia o la confianza en cualquier información contenida en estos sitios web.</p>
            </div>
       </div>)
}
export default ESPmobile