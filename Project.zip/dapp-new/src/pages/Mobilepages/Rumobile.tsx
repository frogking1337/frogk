import React from 'react'
import '../../styles/stylesMin.css'
import PageSelector from '../PageSelector'


const twitter  = require('../../images/twitter.png')
const reddit  = require('../../images/reddit.png')
const discord  = require('../../images/discord.png')
const youtube  = require('../../images/youtube.png')
const tg  = require('../../images/tg.png')
const lightBnb = require('../../images/light-bnb-coins.png')
const lightBnbAir = require('../../images/light-bnb-coins-air.png')
const logoGrey = require("../../images/logo-p-grey.png")


const RUmobile: React.FC = () => {
   
  return  ( 
          <div className="container">
              <PageSelector/>
              <div className="main1" style={{width: "75%"}}>
                <p className="grey" style={{marginTop:' 3%', marginBottom: '-5%'}}>
                  ОТКРЫТАЯ БЛОКЧЕЙН СЕТЬ
                </p>
                <p className="white">Стабильный постоянный доход с Interchain.</p>
              </div>

            <div className="main2">
              <div style={{marginRight: 'auto'}}>
                <p className="white" style={{fontWeight: '700'}}>8 до 17%</p>
                <p style={{fontWeight: '400', fontSize: '25px', lineHeight: '32px', marginTop: "-17%"}}>Выплат ROI</p>
              </div>
              <div style={{marginLeft: 'auto'}}>
                <p className="white" style={{fontWeight:"700"}}>5 Уровней</p>
                <p style={{fontWeight: '400', fontSize: '25px', lineHeight: '32px', marginTop: "-15%"}}>Реферальных бонусов</p>
              </div>
            </div>
           <button className="learn">Learn <span>&#8594;</span></button>
            
            <p className="grey" style={{marginTop: "20%"}}>ПОГРУЗИСЬ В Paradigm</p>
            <p className="white" style={{marginTop: "-2%", width: "65%"}}>Самый удобный способ зароботка.</p>

            <div className="main3">
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: '30px'}}>Полный аудит</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Наши инженеры разработали защищенные смартконтракты которые может проверить любой желающий.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: '30px'}}>Децентрализованная сеть</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color:"#D3D3D3"}}>Транзакциями управляет валидатор Paradigm с децентрализованным управлением. Пулы могут перемещать активы только между предписанными позициями, и только пользователи могут удалять свои средства.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Защищенность</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Наш мост Ethereum используется только для передачи инструкций по стратегии. Между Cosmos и Ethereum нет реальных денежных потоков.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)', backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Быстрые транзакции</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Автоматизированное управление подписями для транзакций позволяет стратегиям быстро перемещать ликвидность и получать доход по любым протоколам DeFi.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)', backgroundRepeat: 'no-repeat', backgroundSize:"cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Cosmos Stargate SDK</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Модульный и надежный протокол с Tendermint Consensus обеспечивает проверенный уровень протокола международного класса.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)', backgroundRepeat: 'no-repeat', backgroundSize: "cover" }}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Криптокошельки</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Мы протокол, не связанный с криптокошельками. Деньги хранятся непосредственно в смарт-контрактах Ethereum и депонируются в AAVE. Пользователи могут быть уверены, что всегда могут вывести свои средства.</p>
              </div>
              <button className="learn">Learn <span>&#8594;</span></button>
            </div>
            <div className="back">
              <p className="white" style={{marginTop: '55%', width: "80%"}}>Надежный способ увеличить капитализацию.</p>
              <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: '#D3D3D3', marginTop: "-5%"}}>Блокчейн, который масштабируется.</p>

              <p className="white" style={{fontWeight: '700', marginTop: '15%', marginBottom: '-1%', width:"80%"}}>Услуги генерируют комиссию. Комиссия генерирует вознаграждение.</p>
              <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: '#D3D3D3', width: '60%'}}>Paradigm позволяет сообществам создавать автономные социальные сети, в которых каждый пользователь может иметь право голоса, создавать ценность и извлекать выгоду из создания ценности другими. Комиссии за транзакции распределяются между участниками Paradigm.</p>
              <p style={{fontWeight: '600', fontSize: '19px', lineHeight: '25px'}}>Что такое стейкинг <span>&#8594;</span></p>
            </div>
            <div className="main4">
              <div className="block block1" style={{width: '90%'}}> 
                <p className="subtitle">Gen 1.0</p>
                <p className="subtitle" style={{marginTop: "90%"}}>Gen 2.0</p>
              </div>
              <div className="block block2">
                <p className="subtitle">Gen 3.0</p>
                
              </div>
            </div>
            <div className="block block3 flex2">
              <div>
                <p className="white" style={{width: '80%', marginTop: 'auto', lineHeight: '24px', fontSize: "24px"}}>Готовы начать стейкинг?</p>
                <p style={{fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: '#D3D3D3', width: '85%', marginTop: "-5%"}}>Чем больше активности в хабе, тем больше комиссионных платят сервисы, что, в свою очередь, приносит вознаграждение участникам Paradigm.</p>
                <button className="learn" style={{width: '129px', height: "33px"}}>STAKE</button>
              </div>
              <img src={lightBnbAir} style={{width: '165%', marginLeft: "-40%", marginTop:'-20%'}}/>
            </div>  
            <div className="main5"> 
              <div className="block block4" id="a">
                <p className="grey" style={{width: '100%',  fontSize: '18px', marginTop:' 12%'}}>ВКЛАДЫ</p>
                <img src={lightBnb} style={{width: "130%"}}/>
                <p className="white" style={{fontWeight: '700', fontSize: '21px', lineHeight: 'normal', width:"120%"}}>Погрузитесь в Paradigm.</p>
              </div>
              <div className="block block5" id="b">
                <p className="grey" style={{marginTop: '5%',  fontSize: "18px"}}>СВЯЗЬ</p>
                <p style={{fontWeight: '700', fontSize: '21px', lineHeight: 'normal', marginTop: "5%"}}>Соедините цепочки</p>
                <p style={{fontWeight: '500', fontSize: '14px', lineHeight: '18px', color: '#9D9D9D', marginTop: '5%', width:"100%"}}>Paradigm позволит пользователям беспрепятственно обмениваться цифровыми активами, поступающими со всей сети.</p>
              </div>
              <div className="block block6" id="c">
                <p className="grey" style={{marginTop: '5%', fontSize: '18px'}}>ВНЕДРЕНИЕ</p>
                <p style={{fontWeight: '600', fontSize: '21px', marginTop: '-5%', width: '80%', lineHeight: "normal"}}>Обеспечивайте ликвидность и получайте награду.</p>
              </div>
            </div>

            <div> 
              <p className="swhite2" style={{fontSize: '38px', marginBottom:"-15px"}}>Получать новости</p>
              <p className="grey">Вы можете отписаться в любой момент.</p>
              <a href="#" className="link1 grey" style={{marginLeft:'1%', marginTop: "-1%"}}>Privacy policy↗</a>
            </div>
            <form style={{marginLeft: '-20%', marginRight: '0px', marginTop: "5%"}}>
              <label></label>
              <input type="email" className="email" placeholder="Your Email" style={{width: '64%', height: '52px', background: '#262524', borderRadius: '12px', fontStyle: 'normal', fontWeight: '400', fontSize: '18px', lineHeight: '36px', color: '#9D9D9D', paddingLeft: '10px', marginTop: '4%', marginLeft: '25%', marginBottom: '5%', border: "none"}} />
            </form>
            <hr/>
            <div className="last">
              <div className="links">
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>Создавай</p>
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>Исследуй</p>
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>Участвуй</p>
                <a href="#"  className="link1">Депозиты↗</a>
                <a href="#"  className="link1">Аудит↗</a>
                <a href="#"  className="link1">Telegram↗</a>
                <a href="#"  className="link1">IBC Protocol↗</a>
                <a href="#"  className="link1">Контракты↗</a>
                <a href="#"  className="link1">Сообщество↗</a>
                <a href="#"  className="link1">Стейкинг↗</a>
                <a href="#"  className="link1">Кошельки</a>
              </div>
            </div>
            <hr/>
            <div className="end" style={{flexDirection: 'column'}}>
              <div className="flex">
                <img src={logoGrey} style={{width: '35%', height: '10%', marginTop: "13px"}}/>
                <div style={{marginTop: '2.5%', marginLeft:"auto"}}>
                  <img src={twitter} style={{margin: "5px"}}/>
                  <img src={reddit} style={{margin: "5px"}}/>
                  <img src={tg} style={{margin: "5px"}}/>
                  <img src={youtube} style={{margin: '5px', marginBottom: "3px"}}/>
                  <img src={discord} style={{margin: "5px"}}/>
                </div>
              </div>
              <p style={{fontStyle: 'normal', fontWeight: '500', fontSize: '9px', lineHeight: '15px', color: "#9D9D9D"}}>Этот веб-сайт поддерживается. Содержание и мнения этого веб-сайта принадлежат Paradigm. Paradigm предоставляет ссылки на биржи криптовалют в качестве общедоступной услуги. Paradigm не гарантирует, что информация, предоставляемая этими веб-сайтами, является правильной, полной и актуальной. Paradigm не несет ответственности за их содержание и прямо отвергает любую ответственность за ущерб любого рода, возникший в результате использования, ссылки или доверия к любой информации, содержащейся на этих веб-сайтах.</p>
            </div>
       </div>)
}
export default RUmobile