import React from 'react'
import '../../styles/stylesMin.css'
import PageSelector from '../PageSelector'
const twitter  = require('../../images/twitter.png')
const reddit  = require('../../images/reddit.png')
const discord  = require('../../images/discord.png')
const youtube  = require('../../images/youtube.png')
const tg  = require('../../images/tg.png')
const lightBnb = require('../../images/light-bnb-coins.png')
const lightBnbAir = require('../../images/light-bnb-coins-air.png')
const logoGrey = require("../../images/logo-p-grey.png")


const Engmobile: React.FC = () => {
   
  return  ( 
          <div className="container">
              <PageSelector/>
              <div className="main1" style={{width: "75%"}}>
                <p className="grey" style={{marginTop:' 3%', marginBottom: '-5%'}}>
                  COMMUNITY-OWNED AND OPERATED
                </p>
                <p className="white">Stable & Profitable Yield Farming Dapp on Binance Smart Chain.</p>
              </div>

            <div className="main2">
              <div style={{marginRight: 'auto'}}>
                <p className="white" style={{fontWeight: '700'}}>8 to 17%</p>
                <p style={{fontWeight: '400', fontSize: '25px', lineHeight: '32px', marginTop: "-17%"}}>Daily ROI</p>
              </div>
              <div style={{marginLeft: 'auto'}}>
                <p className="white" style={{fontWeight:"700"}}>5 Levels</p>
                <p style={{fontWeight: '400', fontSize: '25px', lineHeight: '32px', marginTop: "-15%"}}>Of Referral Rewards</p>
              </div>
            </div>
           <button className="learn">Learn <span>&#8594;</span></button>
            
            <p className="grey" style={{marginTop: "20%"}}>ENTER THE Paradigm</p>
            <p className="white" style={{marginTop: "-2%", width: "65%"}}>The best way to earn Paradigm.</p>

            <div className="main3">
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: '30px'}}>Fully auditable</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>All Paradigm Smart Contracts have undergone extensive internal reviews by our highly sophisticated solidity engineers in addition to multiple external security audits. Paradigm Contracts are fully auditable by anyone.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: '30px'}}>Decentralized</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color:"#D3D3D3"}}>Transactions are managed by the Paradigm validator set with decentralized governance. Pools can only move assets among the prescribed positions and only users can remove their funds.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Safe bridge</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Our Ethereum bridge is used only to pass strategy instructions. No actual funds are flowing between Cosmos and Ethereum.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)', backgroundRepeat: 'no-repeat', backgroundSize: "cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Fast execution</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Automated signature management for transactions enables strategies to rapidly move liquidity and capture yield on any DeFi protocols.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)', backgroundRepeat: 'no-repeat', backgroundSize:"cover"}}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Cosmos Stargate SDK</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>Modular and robust protocol with Tendermint Consensus delivers a world-className and tested protocol layer.</p>
              </div>
              <div>
                <div style={{width: '107px',height: '107px', borderRadius: '28px', backgroundImage: 'url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)', backgroundRepeat: 'no-repeat', backgroundSize: "cover" }}></div>
                <p style={{fontWeight: '600', fontSize: '18px', lineHeight: "30px"}}>Non-custodial</p>
                <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: "#D3D3D3"}}>We are a non-custodial protocol. Money is stored directly on Ethereum smart contracts and deposited to AAVE. Users have the peace of mind that they can always remove their funds.</p>
              </div>
              <button className="learn">Learn <span>&#8594;</span></button>
            </div>
            <div className="back">
              <p className="white" style={{marginTop: '55%', width: "80%"}}>The most trusted way to build value.</p>
              <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: '#D3D3D3', marginTop: "-5%"}}>Blockchain tech that truly scales.</p>

              <p className="white" style={{fontWeight: '700', marginTop: '15%', marginBottom: '-1%', width:"80%"}}>Services generate fees. Fees generate rewards.</p>
              <p style={{fontWeight: '500', fontSize: '19px', lineHeight: '25px', color: '#D3D3D3', width: '60%'}}>Paradigm empowers communities to build autonomous social networks in which every user can have a voice, create value, and benefit from the value creation of others. Transaction fees are distributed to staked Paradigm holders.</p>
              <p style={{fontWeight: '600', fontSize: '19px', lineHeight: '25px'}}>What is staking <span>&#8594;</span></p>
            </div>
            <div className="main4">
              <div className="block block1" style={{width: '90%'}}> 
                <p className="subtitle">Gen 1.0</p>
                <p className="subtitle" style={{marginTop: "90%"}}>Gen 2.0</p>
              </div>
              <div className="block block2">
                <p className="subtitle">Gen 3.0</p>
                
              </div>
            </div>
            <div className="block block3 flex2">
              <div>
                <p className="white" style={{width: '80%', marginTop: 'auto', lineHeight: '24px', fontSize: "24px"}}>Ready to start staking?</p>
                <p style={{fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: '#D3D3D3', width: '85%', marginTop: "-5%"}}>The more activity on the Hub, the more fees paid by services, which in turn, generates rewards for staked Paradigm holders.</p>
                <button className="learn" style={{width: '129px', height: "33px"}}>STAKE</button>
              </div>
              <img src={lightBnbAir} style={{width: '165%', marginLeft: "-40%", marginTop:'-20%'}}/>
            </div>  
            <div className="main5"> 
              <div className="block block4" id="a">
                <p className="grey" style={{width: '100%',  fontSize: '18px', marginTop:' 12%'}}>HOLDERS</p>
                <img src={lightBnb} style={{width: "130%"}}/>
                <p className="white" style={{fontWeight: '700', fontSize: '21px', lineHeight: 'normal', width:"120%"}}>Dive deep into Paradigm.</p>
              </div>
              <div className="block block5" id="b">
                <p className="grey" style={{marginTop: '5%',  fontSize: "18px"}}>CONNECT</p>
                <p style={{fontWeight: '700', fontSize: '21px', lineHeight: 'normal', marginTop: "5%"}}>Connect chains</p>
                <p style={{fontWeight: '500', fontSize: '14px', lineHeight: '18px', color: '#9D9D9D', marginTop: '5%', width:"100%"}}>Paradigm will enable users to seamlessly swap digital assets coming from all over the interchain.</p>
              </div>
              <div className="block block6" id="c">
                <p className="grey" style={{marginTop: '5%', fontSize: '18px'}}>INTEGRATE</p>
                <p style={{fontWeight: '600', fontSize: '21px', marginTop: '-5%', width: '80%', lineHeight: "normal"}}>Provide liquidity. Earn rewards.</p>
              </div>
            </div>

            <div> 
              <p className="swhite2" style={{fontSize: '38px', marginBottom:"-15px"}}>Receive transmissions</p>
              <p className="grey">Unsubscribe at any time.</p>
              <a href="#" className="link1 grey" style={{marginLeft:'1%', marginTop: "-1%"}}>Privacy policy↗</a>
            </div>
            <form style={{marginLeft: '-20%', marginRight: '0px', marginTop: "5%"}}>
              <label></label>
              <input type="email" className="email" placeholder="Your Email" style={{width: '64%', height: '52px', background: '#262524', borderRadius: '12px', fontStyle: 'normal', fontWeight: '400', fontSize: '18px', lineHeight: '36px', color: '#9D9D9D', paddingLeft: '10px', marginTop: '4%', marginLeft: '25%', marginBottom: '5%', border: "none"}} />
            </form>
            <hr/>
            <div className="last">
              <div className="links">
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>Build</p>
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>Explore</p>
                <p className="grey" style={{color: 'white', fontSize: "21px"}}>Participate</p>
                <a href="#"  className="link1">Deposit↗</a>
                <a href="#"  className="link1">Audit↗</a>
                <a href="#"  className="link1">Telegram↗</a>
                <a href="#"  className="link1">IBC Protocol↗</a>
                <a href="#"  className="link1">Contrast↗</a>
                <a href="#"  className="link1">Community↗</a>
                <a href="#"  className="link1">Staking↗</a>
                <a href="#"  className="link1">Wallets</a>
              </div>
            </div>
            <hr/>
            <div className="end" style={{flexDirection: 'column'}}>
              <div className="flex">
                <img src={logoGrey} style={{width: '35%', height: '10%', marginTop: "13px"}}/>
                <div style={{marginTop: '2.5%', marginLeft:"auto"}}>
                  <img src={twitter} style={{margin: "5px"}}/>
                  <img src={reddit} style={{margin: "5px"}}/>
                  <img src={tg} style={{margin: "5px"}}/>
                  <img src={youtube} style={{margin: '5px', marginBottom: "3px"}}/>
                  <img src={discord} style={{margin: "5px"}}/>
                </div>
              </div>
              <p style={{fontStyle: 'normal', fontWeight: '500', fontSize: '9px', lineHeight: '15px', color: "#9D9D9D"}}>This website is maintained by Paradigm. The contents and opinions of this website are those of Paradigm. Paradigm provides links to cryptocurrency exchanges as a service to the public. Paradigm does not warrant that the information provided by these websites is correct, complete, and up-to-date. Paradigm is not responsible for their content and expressly rejects any liability for damages of any kind resulting from the use, reference to, or reliance on any information contained within these websites.</p>
            </div>
       </div>)
}
export default Engmobile