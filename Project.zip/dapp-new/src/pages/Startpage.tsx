import React, { useEffect, useState } from 'react'
import '../styles/style.css'
import PageSelector from './PageSelector'
import Running from './Running'
import Engmobile from './Mobilepages/Engmobile'
const twitter  = require('../images/twitter.png')
const reddit  = require('../images/reddit.png')
const discord  = require('../images/discord.png')
const youtube  = require('../images/youtube.png')
const tg  = require('../images/tg.png')
const mail  = require('../images/mail.png')
const lightBnb = require('../images/light-bnb-coins.png')
const lightBnbAir = require('../images/light-bnb-coins-air.png')
const logoGrey = require("../images/logo-p-grey.png")


const Startpage: React.FC = () => {
  const [dimensions, setDimensions] = useState({ 
    height: window.innerHeight,
    width: window.innerWidth
  });

  useEffect(() => {
    function handleResize() {
      setDimensions({
        height: window.innerHeight,
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [window.innerWidth])

  return (
    <div>{
           dimensions.width<1000?
          (<Engmobile/>)
          :
          (<div className="main-container">
                <PageSelector/>
          <div className="p2">
            <div>
              <p className="grey">COMMUNITY-OWNED AND OPERATED</p>
              <p className="white">Stable & Profitable Yield Farming Dapp on Binance Smart Chain.</p>
              <button className="learn" style={{cursor: "pointer"}}>Learn <span>&#8594;</span> </button>
            </div>
            <div></div>
            <div className="p2-1">
              <p className="white" style={{fontWeight: "700"}}>8 to 17%</p>
              <p className="swhite">Daily ROI</p>
              <p className="white" style={{fontWeight: "700"}}>5 Levels</p>
              <p className="swhite">Of Referral Rewards</p>
            </div>
          </div>
          <Running/>
          <p className="grey" style={{marginLeft: "35%", marginTop: "10%"}}>ENTER THE Paradigm</p>
          <p className="white" style={{marginLeft: "35%", width: '35vh', marginTop: '-15px'}}>The best way to earn Paradigm.</p>
          <div className="back"> 
            <div className="p3">
              <div className="grid1"> 
                <div>
                  <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                  <p className="title">Fully auditable</p>
                  <p className="subtitle">All Paradigm Smart Contracts have undergone extensive internal reviews by our highly sophisticated solidity engineers in addition to multiple external security audits. Paradigm Contracts are fully auditable by anyone.</p>
                </div>

                <div>
                  <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                  <p className="title">Decentralized</p>
                  <p className="subtitle">Transactions are managed by the Paradigm validator set with decentralized governance. Pools can only move assets among the prescribed positions and only users can remove their funds.</p>
                </div>

                <div>
                  <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                  <p className="title">Safe bridge</p>
                  <p className="subtitle">Our Ethereum bridge is used only to pass strategy instructions. No actual funds are flowing between Cosmos and Ethereum.</p>
                </div>
                
                <div>
                  <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                  <p className="title">Fast execution</p>
                  <p className="subtitle">Automated signature management for transactions enables strategies to rapidly move liquidity and capture yield on any DeFi protocols.</p>
                </div>

                <div>
                  <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                  <p className="title">Cosmos Stargate SDK</p>
                  <p className="subtitle">Modular and robust protocol with Tendermint Consensus delivers a world-className and tested protocol layer.</p>
                </div>
                
                <div>
                  <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                  <p className="title">Non-custodial</p>
                  <p className="subtitle">We are a non-custodial protocol. Money is stored directly on Ethereum smart contracts and deposited to AAVE. Users have the peace of mind that they can always remove their funds.</p>
                </div>
              <button className="learn" style={{cursor: "pointer"}}>
                  Learn &#8594; 
              </button>
              </div>
              
              <div className="p3-1">
                <p className="white" style={{width: '60%', marginTop: "-2.3%"}}>The most trusted way to build value.</p>
                <p className="subtitle" style={{marginTop: "-3.5%"}}>Blockchain tech that truly scales.</p>
                <p className="white" style={{fontWeight: "700", marginTop: '10%', width: '70%'}}>Services generate fees. Fees generate rewards.</p>
                <p className="subtitle" style={{marginTop: '-3.5%', width: "55%"}}>Paradigm empowers communities to build autonomous social networks in which every user can have a voice, create value, and benefit from the value creation of others. Transaction fees are distributed to staked Paradigm holders.</p>
                <p className="subtitle" style={{fontWeight: "600"}}>What is staking &#8594;</p>
              </div>
            </div>
          </div>
          <div className="grid5">
            <div className="block11">
              <p className="subtitle">Gen 1.0</p>
              <p className="subtitle">Gen 2.0</p>  
            </div>
            <div className="block12">
              <p className="subtitle" style={{marginTop: "1%"}}>Gen 3.0</p>
              
            </div>
          </div>
          <div className="block13" >
            <div>
              <p style={{fontStyle: "normal", fontWeight: '700', fontSize: '64px', lineHeight: '72px', marginTop: "-5%"}}>Ready to start staking?</p>
              <p className="subtitle" style={{fontWeight: '600', width: "70%"}}>The more activity on the Hub, the more fees paid by services, which in turn, generates rewards for staked Paradigm holders.</p>
              <button className="learn" style={{width: "220px", marginTop: '10%', cursor: "pointer"}}>STAKE</button>
            </div>
            <img className="photo" src={lightBnbAir} alt=''/>
          </div>
          
          <div className="flex1" style={{marginTop: "5%"}}>
            <div className="block14" id="a"  style={{gridArea: "A", paddingLeft: "7%"}}>
              <p className="grey" style={{marginTop:" 0%"}}>HOLDERS</p>
              <img className="photo2" src={lightBnb} alt=''/>
              <p className="swhite2" >Dive deep into Paradigm.</p>
            </div>     
            <div className="block15" id="b" style={{gridArea: "B"}}>
              <p className="grey" style={{marginTop: "-2%", marginLeft: "-2%"}}>CONNECT</p>
              <p className="swhite2" style={{fontWeight: '700', marginLeft: "-2%"}}>Connect chains</p>
              <p style={{fontStyle: "normal", fontWeight: "500", fontSize: "18px", lineHeight: "23px", color: "#9D9D9D", width: "50%", marginLeft: "-2%"}}>Paradigm will enable users to seamlessly swap digital assets coming from all over the interchain.</p>  
            </div>     
            <div className="block16"style={{gridArea: "C"}} id="c">
              <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>INTEGRATE</p>
              <p className="swhite2" style={{width: "", marginLeft: "1%"}}>Provide liquidity. Earn rewards.</p>    
            </div>
            <div className="block17" id="d" style={{gridArea: "D"}}>
              <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>VALIDATE</p>
              <p className="swhite2" style={{fontWeight: "700", width: "70%"}}>+ Ethereum + Bitcoin</p>
          
            </div>
          </div> 
        
          
          <div className="grid4">
            <div> 
              <p className="swhite2" style={{fontSize: "38px", marginBottom: "-15px"}}>Receive transmissions</p>
              <p className="grey">Unsubscribe at any time. <a href="#" className="link1">Privacy policy↗</a></p>
            </div> 
            <form style={{marginLeft:"0%", marginRight: "0px", marginTop: "5%"}}>
              <label></label>
              <input type="email" className="email" placeholder="Your Email" style={{width: "90%", height: "52px", background: "#262524", borderRadius:" 12px", fontStyle: "normal", fontWeight: "400", fontSize: "28px", lineHeight: "36px", color: "#9D9D9D", paddingLeft: "10px", marginTop: "4%", marginLeft: "auto", marginRight:"0px"}} />
            </form>
          </div>
          <hr/>
          <div className="last">
            <div className="links">
              <p className="grey" style={{color: "white", fontSize: "28px"}}>Build</p>
              <p className="grey" style={{color: "white", fontSize: "28px"}}>Explore</p>
              <p className="grey" style={{color: "white", fontSize: "28px"}}>Participate</p>
              <a href="#"  className="link1">Deposit↗</a>
              <a href="#"  className="link1">Audit↗</a>
              <a href="#"  className="link1">Telegram↗</a>
              <a href="#"  className="link1">IBC Protocol↗</a>
              <a href="#"  className="link1">Contrast↗</a>
              <a href="#"  className="link1">Community↗</a>
              <a href="#"  className="link1">Staking↗</a>
              <a href="#"  className="link1">Wallets</a>
            </div>
            <img src={mail} style={{margin: "auto"}} alt=''/>
          </div>
          <hr/>
          <div className="end">
            <img src={logoGrey} style={{width: '15%', height: '10%', marginTop: "auto"}} alt=''/>
            <div style={{marginTop: "1%", marginLeft:"auto"}}>
              <img src={twitter} style={{margin: "5px"}} alt=''/>
              <img src={reddit} style={{margin: "5px"}} alt=''/>
              <img src={tg} style={{margin: "5px"}} alt=''/>
              <img src={discord} style={{marginLeft: "5px", marginRight: "5px", marginBottom: "2px"}} alt=''/>
              <img src={youtube} style={{margin: "5px"}} alt=''/>
            </div>
          </div>  
            <p style={{fontStyle: "normal", fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: "#9D9D9D"}}>This website is maintained by Paradigm. The contents and opinions of this website are those of Paradigm. Paradigm provides links to cryptocurrency exchanges as a service to the public. Paradigm does not warrant that the information provided by these websites is correct, complete, and up-to-date. Paradigm is not responsible for their content and expressly rejects any liability for damages of any kind resulting from the use, reference to, or reliance on any information contained within these websites.</p>
        
        
        </div>)
  }
 </div> 
  )
}
export default Startpage;