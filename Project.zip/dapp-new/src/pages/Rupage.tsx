import React, { useEffect, useState } from 'react'
import '../styles/style.css'
import PageSelector from './PageSelector'
import Running from './Running'
import RUmobile from './Mobilepages/Rumobile'
const twitter  = require('../images/twitter.png')
const reddit  = require('../images/reddit.png')
const discord  = require('../images/discord.png')
const youtube  = require('../images/youtube.png')
const tg  = require('../images/tg.png')
const mail  = require('../images/mail.png')
const lightBnb = require('../images/light-bnb-coins.png')
const lightBnbAir = require('../images/light-bnb-coins-air.png')
const logoGrey = require("../images/logo-p-grey.png")


const RUpage: React.FC = () => {
  const [dimensions, setDimensions] = useState({ 
    height: window.innerHeight,
    width: window.innerWidth
  });

  useEffect(() => {
    function handleResize() {
      setDimensions({
        height: window.innerHeight,
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [window.innerWidth])

 
  return ( 
          <div>
            {
              dimensions.width<1000?
              (<RUmobile/>)
              :
              (<div className="main-container">
                  <PageSelector/>
              <div className="p2">
                <div>
                  <p className="grey">ОТКРЫТАЯ БЛОКЧЕЙН СЕТЬ</p>
                  <p className="white">Стабильный постоянный доход с Interchain.</p>
                  <button className="learn" style={{cursor: "pointer"}}>Learn <span>&#8594;</span> </button>
                </div>
                <div></div>
                <div className="p2-1">
                  <p className="white" style={{fontWeight: "700"}}>от 8 до 17%</p>
                  <p className="swhite">Выплат ROI</p>
                  <p className="white" style={{fontWeight: "700"}}>5 Уровней</p>
                  <p className="swhite">Реферальных бонусов</p>
                </div>
              </div>

              <Running/>
              <p className="grey" style={{marginLeft: "35%", marginTop: "10%"}}>ПОГРУЗИСЬ В Paradigm</p>
              <p className="white" style={{marginLeft: "35%", width: '35vh', marginTop: '-15px'}}>Самый удобный способ зароботка.</p>
              <div className="back"> 
                <div className="p3">
                  <div className="grid1"> 
                    <div>
                      <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                      <p className="title">Полный аудит</p>
                      <p className="subtitle">Наши инженеры разработали защищенные смартконтракты которые может проверить любой желающий.</p>
                    </div>

                    <div>
                      <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                      <p className="title">Децентрализованная сеть</p>
                      <p className="subtitle">Транзакциями управляет валидатор Paradigm с децентрализованным управлением. Пулы могут перемещать активы только между предписанными позициями, и только пользователи могут удалять свои средства.</p>
                    </div>

                    <div>
                      <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                      <p className="title">Защищенность</p>
                      <p className="subtitle">Наш мост Ethereum используется только для передачи инструкций по стратегии. Между Cosmos и Ethereum нет реальных денежных потоков.</p>
                    </div>
                    
                    <div>
                      <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                      <p className="title">Быстрые транзакции</p>
                      <p className="subtitle">Автоматизированное управление подписями для транзакций позволяет стратегиям быстро перемещать ликвидность и получать доход по любым протоколам DeFi.</p>
                    </div>

                    <div>
                      <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                      <p className="title">Cosmos Stargate SDK</p>
                      <p className="subtitle">Модульный и надежный протокол с Tendermint Consensus обеспечивает проверенный уровень протокола международного класса.</p>
                    </div>
                    
                    <div>
                      <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
                      <p className="title">Криптокошельки</p>
                      <p className="subtitle">Мы протокол, не связанный с криптокошельками. Деньги хранятся непосредственно в смарт-контрактах Ethereum и депонируются в AAVE. Пользователи могут быть уверены, что всегда могут вывести свои средства.</p>
                    </div>
                  <button className="learn" style={{cursor: "pointer"}}>
                      Learn &#8594; 
                  </button>
                  </div>
                  
                  <div className="p3-1">
                    <p className="white" style={{width: '60%', marginTop: "-2.3%"}}>Надежный способ увеличить капитализацию.</p>
                    <p className="subtitle" style={{marginTop: "-3.5%"}}>Блокчейн, который масштабируется.</p>
                    <p className="white" style={{fontWeight: "700", marginTop: '10%', width: '70%'}}>Услуги генерируют комиссию. Комиссия генерирует вознаграждение.</p>
                    <p className="subtitle" style={{marginTop: '-3.5%', width: "55%"}}>Paradigm позволяет сообществам создавать автономные социальные сети, в которых каждый пользователь может иметь право голоса, создавать ценность и извлекать выгоду из создания ценности другими. Комиссии за транзакции распределяются между участниками Paradigm.</p>
                    <p className="subtitle" style={{fontWeight: "600"}}>Что такое стейкинг &#8594;</p>
                  </div>
                </div>
              </div>
              <div className="grid5">
                <div className="block11">
                  <p className="subtitle">Gen 1.0</p>
                  <p className="subtitle">Gen 2.0</p>  
                </div>
                <div className="block12">
                  <p className="subtitle" style={{marginTop: "1%"}}>Gen 3.0</p>
                  
                </div>
              </div>
              <div className="block13" >
                <div>
                  <p style={{fontStyle: "normal", fontWeight: '700', fontSize: '64px', lineHeight: '72px', marginTop: "-5%"}}>Готовы начать стейкинг?</p>
                  <p className="subtitle" style={{fontWeight: '600', width: "70%"}}>Чем больше активности в хабе, тем больше комиссионных платят сервисы, что, в свою очередь, приносит вознаграждение участникам Paradigm.</p>
                  <button className="learn" style={{width: "220px", marginTop: '10%', cursor: "pointer"}}>STAKE</button>
                </div>
                <img className="photo" src={lightBnbAir} alt=''/>
              </div>

              <div className="flex1" style={{marginTop: "5%"}}>
                <div className="block14" id="a"  style={{gridArea: "A", paddingLeft: "7%"}}>
                  <p className="grey" style={{marginTop:" 0%"}}>ВКЛАДЫ</p>
                  <img className="photo2" src={lightBnb} alt=''/>
                  <p className="swhite2" >Погрузитесь в Paradigm.</p>
                </div>     
                <div className="block15" id="b" style={{gridArea: "B"}}>
                  <p className="grey" style={{marginTop: "-2%", marginLeft: "-2%"}}>СВЯЗЬ</p>
                  <p className="swhite2" style={{fontWeight: '700', marginLeft: "-2%"}}>Соедините цепочки</p>
                  <p style={{fontStyle: "normal", fontWeight: "500", fontSize: "18px", lineHeight: "23px", color: "#9D9D9D", width: "50%", marginLeft: "-2%"}}>Paradigm позволит пользователям беспрепятственно обмениваться цифровыми активами, поступающими со всей сети.</p>  
                </div>     
                <div className="block16"style={{gridArea: "C"}} id="c">
                  <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>ВНЕДРЕНИЕ</p>
                  <p className="swhite2" style={{width: "", marginLeft: "1%"}}>Обеспечивайте ликвидность и получайте награду.</p>    
                </div>
                <div className="block17" id="d" style={{gridArea: "D"}}>
                  <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>ПОДДЕРЖКА</p>
                  <p className="swhite2" style={{fontWeight: "700", width: "70%"}}>+ Ethereum + Bitcoin</p>
              
                </div>
              </div> 


              <div className="grid4">
                <div> 
                  <p className="swhite2" style={{fontSize: "38px", marginBottom: "-15px"}}>Получать новости</p>
                  <p className="grey">Вы можете отписаться в любой момент.<br/> <a href="#" className="link1">Privacy policy↗</a></p>
                </div> 
                <form style={{marginLeft:"0%", marginRight: "0px", marginTop: "5%"}}>
                  <label></label>
                  <input type="email" className="email" placeholder="Your Email" style={{width: "90%", height: "52px", background: "#262524", borderRadius:" 12px", fontStyle: "normal", fontWeight: "400", fontSize: "28px", lineHeight: "36px", color: "#9D9D9D", paddingLeft: "10px", marginTop: "4%", marginLeft: "auto", marginRight:"0px"}} />
                </form>
              </div>
              <hr/>
              <div className="last">
                <div className="links">
                  <p className="grey" style={{color: "white", fontSize: "28px"}}>Создавай</p>
                  <p className="grey" style={{color: "white", fontSize: "28px"}}>Исследуй</p>
                  <p className="grey" style={{color: "white", fontSize: "28px"}}>Участвуй</p>
                  <a href="#"  className="link1">Депозиты↗</a>
                  <a href="#"  className="link1">Аудит↗</a>
                  <a href="#"  className="link1">Telegram↗</a>
                  <a href="#"  className="link1">IBC Protocol↗</a>
                  <a href="#"  className="link1">Контракты↗</a>
                  <a href="#"  className="link1">Сообщество↗</a>
                  <a href="#"  className="link1">Стейкинг↗</a>
                  <a href="#"  className="link1">Кошельки</a>
                </div>
                <img src={mail} style={{margin: "auto"}} alt=''/>
              </div>
              <hr/>
              <div className="end">
                <img src={logoGrey} style={{width: '15%', height: '10%', marginTop: "auto"}} alt=''/>
                <div style={{marginTop: "1%", marginLeft:"auto"}}>
                  <img src={twitter} style={{margin: "5px"}} alt=''/>
                  <img src={reddit} style={{margin: "5px"}} alt=''/>
                  <img src={tg} style={{margin: "5px"}} alt=''/>
                  <img src={discord} style={{marginLeft: "5px", marginRight: "5px", marginBottom: "2px"}} alt=''/>
                  <img src={youtube} style={{margin: "5px"}} alt=''/>
                </div>
              </div>  
                <p style={{fontStyle: "normal", fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: "#9D9D9D"}}>This website is maintained by Paradigm. The contents and opinions of this website are those of Paradigm. Paradigm provides links to cryptocurrency exchanges as a service to the public. Paradigm does not warrant that the information provided by these websites is correct, complete, and up-to-date. Paradigm is not responsible for their content and expressly rejects any liability for damages of any kind resulting from the use, reference to, or reliance on any information contained within these websites.</p>
              </div> 
            )}
          </div> )
}
export default RUpage;