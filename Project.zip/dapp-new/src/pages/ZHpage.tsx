import React, { useEffect, useState } from 'react'
import '../styles/style.css'
import PageSelector from './PageSelector'
import Running from './Running'
import ZHmobile from './Mobilepages/Zhmobile'
const twitter  = require('../images/twitter.png')
const reddit  = require('../images/reddit.png')
const discord  = require('../images/discord.png')
const youtube  = require('../images/youtube.png')
const tg  = require('../images/tg.png')
const mail  = require('../images/mail.png')
const lightBnb = require('../images/light-bnb-coins.png')
const lightBnbAir = require('../images/light-bnb-coins-air.png')
const logoGrey = require("../images/logo-p-grey.png")


const ZHpage: React.FC = () => {
  const [dimensions, setDimensions] = useState({ 
    height: window.innerHeight,
    width: window.innerWidth
  });

  useEffect(() => {
    function handleResize() {
      setDimensions({
        height: window.innerHeight,
        width: window.innerWidth
      })
    }
    window.addEventListener('resize', handleResize)
    return () => {
      window.removeEventListener('resize', handleResize)
    }
  }, [window.innerWidth])
  return (<div>
    {
      dimensions.width<1000?
      (<ZHmobile/>)
      :
      (
    
    <div className="main-container">
           <PageSelector/>
     <div className="p2">
      <div>
        <p className="grey">社区拥有和经营</p>
        <p className="white">稳定且盈利的高产农业跨链 DEX</p>
        <button className="learn" style={{cursor: "pointer"}}>赌注 <span>&#8594;</span> </button>
      </div>
      <div></div>
      <div className="p2-1">
        <p className="white" style={{fontWeight: "700"}}>8% 到 17%</p>
        <p className="swhite">每日投资回报率</p>
        <p className="white" style={{fontWeight: "700"}}>5 级</p>
        <p className="swhite">推荐奖励</p>
      </div>
    </div>
  
    <Running/>
    <p className="grey" style={{marginLeft: "35%", marginTop: "10%"}}>输入 Paradigm</p>
    <p className="white" style={{marginLeft: "35%", width: '35vh', marginTop: '-15px'}}>最好的方法赚取资产</p>
    <div className="back"> 
      <div className="p3">
        <div className="grid1"> 
          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444201537576/audit.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">经审计的智能合约</p>
            <p className="subtitle">由 HazeCrypto 测试和验证。将在安全稳定的基础上运营公平、快速增长和低费用的项目。</p>
          </div>

          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963443970838538/anti-whale.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">反鲸功能</p>
            <p className="subtitle">交易由具有去中心化治理的范式验证器集管理。矿池只能在规定的仓位之间移动资产，并且只有用户可以取出他们的资金。</p>
          </div>

          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444788731944/referal.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">安全桥梁</p>
            <p className="subtitle">我们的以太坊桥仅用于传递策略指令。 Cosmos 和以太坊之间没有实际资金流动。</p>
          </div>
          
          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445556293673/support.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">快速执行</p>
            <p className="subtitle">交易的自动签名管理使策略能够快速移动流动性并捕获任何 DeFi 协议的收益。</p>
          </div>

          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963444478345216/income.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">Cosmos Stargate SDK</p>
            <p className="subtitle">具有 Tendermint 共识的模块化和强大的协议提供了世界一流的和经过测试的协议层。</p>
          </div>
          
          <div>
            <div className="block1" style={{backgroundImage: "url(https://cdn.discordapp.com/attachments/300176676644716544/1019963445073956926/security.png)", backgroundRepeat: "no-repeat", backgroundSize: "cover"}}></div>
            <p className="title">非托管</p>
            <p className="subtitle">我们是一个非托管协议。资金直接存储在以太坊智能合约上并存入 AAVE。用户可以放心，他们可以随时取出资金</p>
          </div>
        <button className="learn" style={{cursor: "pointer"}}>
        赌注 &#8594; 
        </button>
        </div>
        
        <div className="p3-1">
          <p className="white" style={{width: '60%', marginTop: "-2.3%"}}>最值得信赖的创造价值的方式。</p>
          <p className="subtitle" style={{marginTop: "-3.5%"}}>真正可扩展的区块链技术。</p>
          <p className="white" style={{fontWeight: "700", marginTop: '10%', width: '70%'}}>服务产生费用。 费用产生回报。</p>
          <p className="subtitle" style={{marginTop: '-3.5%', width: "55%"}}>Paradigm 使社区能够建立自治的社交网络，每个用户都可以在其中拥有发言权、创造价值并从他人的价值创造中受益。 交易费用分配给质押的范式持有人。</p>
          <p className="subtitle" style={{fontWeight: "600"}}>什么是质押 &#8594;</p>
        </div>
      </div>
    </div>
    <div className="grid5">
      <div className="block11">
        <p className="subtitle">1.0 代</p>
        <p className="subtitle">2.0 代</p>  
      </div>
      <div className="block12">
        <p className="subtitle" style={{marginTop: "1%"}}>3.0 代</p>
        
      </div>
    </div>
    <div className="block13" >
      <div>
        <p style={{fontStyle: "normal", fontWeight: '700', fontSize: '64px', lineHeight: '72px', marginTop: "-5%"}}>准备开始质押？</p>
        <p className="subtitle" style={{fontWeight: '600', width: "70%"}}>Hub 上的活动越多，服务支付的费用就越多，这反过来又会为质押的 Paradigm 持有者产生奖励。</p>
        <button className="learn" style={{width: "220px", marginTop: '10%', cursor: "pointer"}}>赌注</button>
      </div>
      <img className="photo" alt='' src={lightBnbAir}/>
    </div>
    
    <div className="flex1" style={{marginTop: "5%"}}>
      <div className="block14" id="a"  style={{gridArea: "A", paddingLeft: "7%"}}>
        <p className="grey" style={{marginTop:" 0%"}}>持有人</p>
        <img className="photo2" src={lightBnb} alt=''/>
        <p className="swhite2" >深入研究范式。</p>
      </div>     
      <div className="block15" id="b" style={{gridArea: "B"}}>
        <p className="grey" style={{marginTop: "-2%", marginLeft: "-2%"}}>连接</p>
        <p className="swhite2" style={{fontWeight: '700', marginLeft: "-2%"}}>连接链</p>
        <p style={{fontStyle: "normal", fontWeight: "500", fontSize: "18px", lineHeight: "23px", color: "#9D9D9D", width: "50%", marginLeft: "-2%"}}>Paradigm 将使用户能够无缝地交换来自整个 Interchain 的数字资产。</p>  
      </div>     
      <div className="block16"style={{gridArea: "C"}} id="c">
        <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>整合</p>
        <p className="swhite2" style={{width: "", marginLeft: "1%"}}>提供流动性。赚取奖励。</p>    
      </div>
      <div className="block17" id="d" style={{gridArea: "D"}}>
        <p className="grey" style={{marginTop: '1%', marginLeft: "1%"}}>证实</p>
        <p className="swhite2" style={{fontWeight: "700", width: "70%"}}>+ Ethereum + Bitcoin</p>
     
      </div>
    </div> 
   
    
    <div className="grid4">
      <div> 
        <p className="swhite2" style={{fontSize: "38px", marginBottom: "-15px"}}>接收邮件</p>
        <p className="grey">随时退订。 <a href="#" className="link1">隐私政策↗</a></p>
      </div> 
      <form style={{marginLeft:"0%", marginRight: "0px", marginTop: "5%"}}>
        <label></label>
        <input type="email" className="email" placeholder="Your Email" style={{width: "90%", height: "52px", background: "#262524", borderRadius:" 12px", fontStyle: "normal", fontWeight: "400", fontSize: "28px", lineHeight: "36px", color: "#9D9D9D", paddingLeft: "10px", marginTop: "4%", marginLeft: "auto", marginRight:"0px"}} />
      </form>
    </div>
    <hr/>
    <div className="last">
      <div className="links">
        <p className="grey" style={{color: "white", fontSize: "28px"}}>建造</p>
        <p className="grey" style={{color: "white", fontSize: "28px"}}>探索</p>
        <p className="grey" style={{color: "white", fontSize: "28px"}}>参加</p>
        <a href="#"  className="link1">订金↗</a>
        <a href="#"  className="link1">审计↗</a>
        <a href="#"  className="link1">Telegram↗</a>
        <a href="#"  className="link1">IBC Protocol↗</a>
        <a href="#"  className="link1">对比↗</a>
        <a href="#"  className="link1">社区↗</a>
        <a href="#"  className="link1">质押↗</a>
        <a href="#"  className="link1">钱包</a>
      </div>
      <img src={mail} style={{margin: "auto"}} alt=''/>
    </div>
    <hr/>
    <div className="end">
      <img src={logoGrey} style={{width: '15%', height: '10%', marginTop: "auto"}} alt=''/>
      <div style={{marginTop: "1%", marginLeft:"auto"}} >
        <img src={twitter} style={{margin: "5px"}} alt=''/>
        <img src={reddit} style={{margin: "5px"}} alt=''/>
        <img src={tg} style={{margin: "5px"}} alt=''/>
        <img src={discord} style={{marginLeft: "5px", marginRight: "5px", marginBottom: "2px"}} alt=''/>
        <img src={youtube} style={{margin: "5px"}} alt=''/>
      </div>
    </div>  
      <p style={{fontStyle: "normal", fontWeight: '500', fontSize: '15px', lineHeight: '20px', color: "#9D9D9D"}}>本网站的内容是 Paradigm 的。 Paradigm 向公众提供加密货币交易所的链接作为服务。 Paradigm 不保证这些网站提供的信息是正确、完整和最新的。 Paradigm 对其内容不承担任何责任，并明确拒绝对因使用、参考或依赖这些网站中包含的任何信息而造成的任何形式的损害承担任何责任。</p>
   
  
  </div>)}
  </div>
  )
}
export default ZHpage;