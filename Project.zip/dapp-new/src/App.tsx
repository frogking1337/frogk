import './App.css';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Startpage from './pages/Startpage';
import RUpage from './pages/Rupage';
import Esppage from './pages/Esppage';
import ZHpage from './pages/ZHpage';
import Home from './pages/Wallet/Wallet';
import Metadata from './components/Metadata';
import { ChainDataContextProvider } from './contexts/ChainDataContext';
import { ClientContextProvider } from './contexts/ClientContext';
import { JsonRpcContextProvider } from './contexts/JsonRpcContext';
import { globalStyle } from "./styles/styles"
import { createGlobalStyle } from 'styled-components';
const GlobalStyle = createGlobalStyle`
  ${globalStyle}
`;

function App() {
  return (
    <div className="App">

      <GlobalStyle />
      <ChainDataContextProvider>
        <ClientContextProvider>
          <JsonRpcContextProvider>
             <BrowserRouter>
                <Routes>
                  <Route path="/" element={<Startpage/>}></Route>
                  <Route path="/ru" element={<RUpage/>}></Route>
                  <Route path="/esp" element={<Esppage/>}></Route>
                  <Route path="/zh" element={<ZHpage/>}></Route>
                  <Route path='/app' element={<Home/>}></Route>
                </Routes>   
              </BrowserRouter>
          </JsonRpcContextProvider>
        </ClientContextProvider>
      </ChainDataContextProvider>
    </div>
  );
}

export default App;
