
import * as React from "react";
import { DEFAULT_APP_METADATA } from "../constants";

const Metadata = () => (
  <h1>
    <title>{DEFAULT_APP_METADATA.name}</title>
    <meta name="description" content={DEFAULT_APP_METADATA.description} />
    <meta name="url" content={DEFAULT_APP_METADATA.url} />

    {DEFAULT_APP_METADATA.icons.map((icon, index) => (
      <link key={index} rel="icon" href={icon} />
    ))}
  </h1>
);

export default Metadata;
