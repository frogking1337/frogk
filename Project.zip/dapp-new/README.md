//commands to use
// install packages 'npm i'
// start local app 'npm run start'
// create build for deploying 'npm run build' -> created build folder with static files